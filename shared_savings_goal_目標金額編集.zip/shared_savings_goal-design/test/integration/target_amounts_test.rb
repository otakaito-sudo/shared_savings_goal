require "test_helper"

class TargetAmountsTest < ActionDispatch::IntegrationTest
  setup do
    @manager = create_activated_user("管理者", "target-manager@example.com")
    @member = create_activated_user("メンバー", "target-member@example.com")
    @outsider = create_activated_user("部外者", "target-outsider@example.com")
    @goal = create_goal(creator: @manager, target_amount: 100_000)
    @manager_membership = @goal.memberships.create!(user: @manager, role: :manager, target_amount: 100_000)
    @member_membership = @goal.memberships.create!(user: @member, role: :member, target_amount: 0)
  end

  def update_targets(total: "120000", manager: "70000", member: "50000")
    patch saving_goal_target_amounts_path(@goal), params: {
      target_amount: total,
      member_targets: { @manager_membership.id.to_s => manager, @member_membership.id.to_s => member }
    }
  end

  test "管理者が全体目標と個人目標を一括で変更できる" do
    log_in_as(@manager)
    get edit_saving_goal_target_amounts_path(@goal)
    assert_response :success
    update_targets
    assert_redirected_to saving_goal_path(@goal)
    assert_equal 120_000, @goal.reload.target_amount
    assert_equal 70_000, @manager_membership.reload.target_amount
    assert_equal 50_000, @member_membership.reload.target_amount
  end

  test "合計が一致しないと何も保存しない" do
    log_in_as(@manager)
    update_targets(total: "100000")
    assert_response :unprocessable_entity
    assert_select ".target-editor__errors", /一致/
    assert_equal 100_000, @goal.reload.target_amount
    assert_equal 100_000, @manager_membership.reload.target_amount
    assert_equal 0, @member_membership.reload.target_amount
  end

  test "不正な金額や欠けたメンバーは保存しない" do
    log_in_as(@manager)
    update_targets(manager: "-1")
    assert_response :unprocessable_entity
    assert_equal 100_000, @goal.reload.target_amount
    patch saving_goal_target_amounts_path(@goal), params: {
      target_amount: "100000", member_targets: { @manager_membership.id.to_s => "100000" }
    }
    assert_response :unprocessable_entity
    assert_equal 100_000, @manager_membership.reload.target_amount
  end

  test "別の目標のメンバーを混ぜることはできない" do
    other_goal = create_goal(creator: @outsider)
    other_membership = other_goal.memberships.create!(user: @outsider, role: :manager, target_amount: 100_000)
    log_in_as(@manager)
    patch saving_goal_target_amounts_path(@goal), params: {
      target_amount: "100000", member_targets: {
        @manager_membership.id.to_s => "100000", @member_membership.id.to_s => "0", other_membership.id.to_s => "1"
      }
    }
    assert_response :unprocessable_entity
    assert_equal 100_000, other_membership.reload.target_amount
  end

  test "管理者以外は変更できない" do
    log_in_as(@member)
    get edit_saving_goal_target_amounts_path(@goal)
    assert_redirected_to saving_goal_path(@goal)
    update_targets
    assert_redirected_to saving_goal_path(@goal)
    assert_equal 100_000, @goal.reload.target_amount
    delete logout_path
    log_in_as(@outsider)
    update_targets
    assert_response :not_found
  end

  test "確認済み入金額以下には変更できない" do
    @goal.deposits.create!(member: @member, request_amount: 30_000, status: :confirmed)
    log_in_as(@manager)
    update_targets(total: "30000", manager: "20000", member: "10000")
    assert_response :unprocessable_entity
    assert_equal 100_000, @goal.reload.target_amount
  end

  test "達成した目標は変更できない" do
    @goal.update!(status: :achieved)
    log_in_as(@manager)
    update_targets
    assert_response :unprocessable_entity
    assert_equal 100_000, @goal.reload.target_amount
  end

  test "個人目標が残るメンバーは削除できない" do
    @manager_membership.update!(target_amount: 50_000)
    @member_membership.update!(target_amount: 50_000)
    log_in_as(@manager)
    assert_no_difference "Membership.count" do
      delete saving_goal_membership_path(@goal, @member_membership)
    end
    assert_match /配分/, flash[:alert]
    assert_equal 100_000, @goal.memberships.sum(:target_amount)
  end

  test "目標作成時は作成者に全額を割り当てる" do
    log_in_as(@manager)
    assert_difference "SavingGoal.count", 1 do
      post saving_goals_path, params: { saving_goal: {
        name: "新しい目標", purpose: "旅行", target_amount: "80000", deadline: 1.month.from_now.to_date.to_s
      } }
    end
    goal = SavingGoal.order(:id).last
    assert_equal 80_000, goal.memberships.find_by!(user: @manager).target_amount
  end
end
